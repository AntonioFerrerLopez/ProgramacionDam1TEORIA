package datos;

import java.sql.*;

public class BDA {

    private Connection conexion;

  //Las excepciones las dejamos que se gestionen desde donde hayan invocado a este método
    public boolean conectar(String usuario, String pwd, String bda) throws SQLException {
     
        String url = "jdbc:mysql://localhost:3306/" + bda+"?serverTimezone=UTC";

        conexion = DriverManager.getConnection(url, usuario, pwd);

        return (conexion != null);

    }
    
  //Las excepciones las dejamos que se gestionen desde donde hayan invocado a este método
    public void desconectar() throws SQLException{
        conexion.close();
    }
}
