package primeraconexion;

import datos.BDA;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ConexionController implements Initializable {

    private boolean conexion;

    private BDA basededatos;

    @FXML
    private Label label;
    @FXML
    private Button bAbrir;
    @FXML
    private TextField usuario;
    @FXML
    private TextField pwd;
    @FXML
    private TextField bda;
    @FXML
    private TextArea consola;
    @FXML
    private Button bCerrar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        basededatos = new BDA();
    }

    @FXML
    private void conectar(ActionEvent event) {
        try {
            String bd = bda.getText();
            String user = usuario.getText();
            String password = pwd.getText();

            conexion = basededatos.conectar(user, password, bd);
            consola.setText("Conectando a la bda.......\n");

            if (conexion) {
                consola.appendText(LocalTime.now() + " Conexión establecida con la base de datos " + bd);
                bCerrar.setDisable(false);
            } else {
                consola.appendText("Conexion nula");
            }
        } catch (SQLException ex) {
            consola.appendText("Error en la conexion. \n Error servidor: " + ex.getMessage());
        }
    }

    @FXML
    private void desconectar(ActionEvent event) {
        try {
            basededatos.desconectar();
            consola.appendText("\n\n" + LocalTime.now() + " Conexion CERRADA");
        } catch (SQLException ex) {
            consola.appendText("Problemas al intentar cerrar: " + ex.getMessage());
        }
    }

}
