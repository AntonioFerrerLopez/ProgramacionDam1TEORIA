/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imc;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 *
 * @author rlopez
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    @FXML
    private Button calcularIMC;
    @FXML
    private TextField altura;
    @FXML
    private TextField peso;
    @FXML
    private TextField imc;
    @FXML
    private RadioButton obesidad;
    @FXML
    private RadioButton sobrepeso;
    @FXML
    private RadioButton normal;
    @FXML
    private RadioButton extradelgadez;
    @FXML
    private ToggleGroup clasificacion;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    @FXML
    private void calcularIMC(ActionEvent event) {
        calculoIMC();
    }
    
    private void calculoIMC() {
        int alt = 0;
        double altMetros = 0, pesoKG = 0;
        Alert alerta = new Alert(AlertType.WARNING);
        alerta.setTitle("ATENCION");
        
        DecimalFormat formato = new DecimalFormat("##.##");
        
        if (!altura.getText().isEmpty()) {
            alt = Integer.parseInt(altura.getText());
            altMetros = alt / 100.0;
        }
        if (!peso.getText().isEmpty()) {
            pesoKG = Double.parseDouble(peso.getText());
        }
        
        if (alt <= 220 && alt >= 40) {
            if (pesoKG <= 180 && pesoKG >= 20) {
                altura.setStyle("-fx-background-color: white;");
                peso.setStyle("-fx-background-color: white;");
                
                Double IMC = pesoKG / (altMetros * altMetros);
                
                imc.setText(formato.format(IMC));
                
                if (IMC >= 30) {
                    clasificacion.selectToggle(obesidad);
                    imc.setStyle("-fx-background-color: red;");
                    alerta.setContentText("Deberias comer menos");
                    alerta.show();
                } else if (25 <= IMC && IMC < 30) {
                    clasificacion.selectToggle(sobrepeso);
                    imc.setStyle("-fx-background-color: white;");
                } else if (18.5 <= IMC && IMC < 25) {
                    clasificacion.selectToggle(normal);
                    imc.setStyle("-fx-background-color: white;");
                } else if (IMC < 18.5) {
                    alerta.setContentText("Deberias comer más");
                    alerta.show();
                    clasificacion.selectToggle(extradelgadez);
                    imc.setStyle("-fx-background-color: yellow;");
                }
                
            } else {
                alerta.setContentText("peso fuera de rango ");
                alerta.show();
                peso.setStyle("-fx-background-color: red;");
                imc.setText("");
                imc.setStyle("-fx-background-color: white;");
            clasificacion.selectToggle(null);
            }
        } else {
            alerta.setContentText(" altura fuera de rango ");
            alerta.show();
            altura.setStyle("-fx-background-color: red;");
            imc.setText("");
            imc.setStyle("-fx-background-color: white;");
            clasificacion.selectToggle(null);
        }
        
    }
    
}
