package TresClases;

public class UsoTriangulos {

    public static void main(String[] args) {

        Equilatero equi = new Equilatero(15);
        Isosceles isos = new Isosceles(15, 10);
        Escaleno esca = new Escaleno(15, 10, 13);

        System.out.println("Area triangulo equilatero 1: " + equi.area());
        System.out.println("Area2 triangulo equilatero 1: " + equi.area2());
        System.out.println("Perimetro triangulo equilatero 1: " + equi.perimetro());
        System.out.println("Altura triangulo equilatero 1: " + equi.altura());

        System.out.println("");
        System.out.println("Area triangulo isosceles 1: " + isos.area());
        System.out.println("Perimetro triangulo isosceles 1: " + isos.perimetro());
        System.out.println("Altura triangulo isosceles 1: " + isos.altura());

        System.out.println("");
        System.out.println("Area triangulo escaleno 1: " + esca.area());
        System.out.println("Perimetro triangulo escaleno 1: " + esca.perimetro());

    }

}
