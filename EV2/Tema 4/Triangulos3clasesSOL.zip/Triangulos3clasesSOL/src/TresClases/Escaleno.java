package TresClases;

public class Escaleno {

    private double lado, base, lado2;

    public Escaleno(double lad, double bas, double lad2) {
// MétodoConstructor
        lado = lad;
        base = bas;
        lado2 = lad2;
    }

    public double getlado() {
        return lado;
    }

    public double getbase() {
        return base;
    }

    public double getlado2() {
        return lado2;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public void setLado2(double lado2) {
        this.lado2 = lado2;
    }
    

    public double area() {
        double semi = this.perimetro() / 2;
        return Math.sqrt(semi * (semi - lado) * (semi - lado2) * (semi - base));

    }

    public double perimetro() {
        return lado + lado2 + base;

    }
}
