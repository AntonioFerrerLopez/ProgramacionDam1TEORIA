package TresClases;

public class Isosceles {

    private double lado, base;

    public Isosceles(double lad, double bas) {
// MétodoConstructor
        lado = lad;
        base = bas;
    }

    public double getlado() {
        return lado;
    }

    public double getbase() {
        return base;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }

    public void setBase(double base) {
        this.base = base;
    }

    
// ***********OTROS METODOS **************
    
    public double area() {
        return (base * this.altura()) / 2;
    }

    public double altura() {
        return Math.sqrt((lado * lado) - ((base * base) / 4));
    }

    public double perimetro() {
        return lado + lado + base;

    }

}
