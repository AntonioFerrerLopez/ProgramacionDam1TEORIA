
package TresClases;


public class Equilatero {
   private double lado;

    public Equilatero(double lad) {
// MétodoConstructor
        lado = lad;
    }

    public double getlado() {
        return lado;
    }

    public void setlado(double valor) {
        lado = valor;
    }

     public double area2() {            
        return  (lado * altura())/2;
    }
    
    public double area() {            
        return  (Math.sqrt(3)*(lado*lado))/4;
    }

 

    public double perimetro() {
        return 3 * lado;

    }
     public double altura() {
        return (lado/2)*Math.sqrt(3);

    }
}


