package figuras;

public class Circulo {

    //atributo radio del circulo
    private double radio;

    //METODO CONSTRUCTOR con un parámetro rad que se almacena en el atributo radio
    public Circulo(double rad) {
        radio = rad;
    }

    public double getradio() {
        return radio;
    }

    public void setradio(double valor) {
        radio = valor;
    }

    public double area() {
        return Math.PI * radio * radio;
    }

    public double diametro() {
        return radio + radio;
    }

    public double perimetro() {
        return 2 * radio * Math.PI;
    }

    //IMPORTANTE: El método necesita un parámetro angulo para poder calcular 
    // el area de ese sector
    public double areaSector(double angulo) {
        return (angulo / 360) * radio * radio * Math.PI;
    }
}
