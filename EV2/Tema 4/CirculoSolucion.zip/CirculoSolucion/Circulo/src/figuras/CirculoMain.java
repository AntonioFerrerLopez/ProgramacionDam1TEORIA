package figuras;

public class CirculoMain {

    public static void main(String[] args) {
        //creamos dos circulos
        Circulo circulo1 = new Circulo(10.0);
        Circulo circulo2 = new Circulo(20.0);
        Cuadrado cuadrado = new Cuadrado(15);

        //mostramos el area de los dos circulos
        System.out.println("Area del circulo1:" + circulo1.area());
        System.out.println("Area del circulo2:" + circulo2.area());

        //Modificamos el radio del circulo c1 y mostramos su area
        circulo1.setradio(7.0);
        System.out.println("Nueva area del circulo1:" + circulo1.area());

        //modificaremos el radio del circulo1
        circulo1.setradio(10.0);

        //mostramos el diametro del circulo 1 y 2
        System.out.println("El diametro del circulo1 es:" + circulo1.diametro());
        System.out.println("El diametro del circulo2 es:" + circulo2.diametro());

        //calculamos el perimetro de los circulos
        System.out.println("El perimetro del circulo1 es:" + circulo1.perimetro());
        System.out.println("El perimetro del circulo2 es:" + circulo2.perimetro());

//calcular el area de un sector del circulo en funcion del angulo y del radio
        System.out.println("El angulo del circulo1 es:" + circulo1.areaSector(90));

        //mostras diametro,area,perimetro,areaSector
        System.out.println("El diametro del circulo2 es:" + circulo2.diametro());
        System.out.println("El area del circulo2 es:" + circulo2.area());
        System.out.println("El perimetro del circulo2 es :" + circulo2.perimetro());
        System.out.println("El areaSector del circulo2 es :" + circulo2.areaSector(30));

//calculamos el perimetro de un cuadrado
        System.out.println("El perimetro del cuadrado es:" + cuadrado.perimetro());
        //calcular el area del cuadrado
        System.out.println("El area del cuadrado es:" + cuadrado.area());
        //calcular cuantos lados tiene el cuadrado
        System.out.println("El cuadrado tiene:" + cuadrado.lados() + " lados ");
    }

}
