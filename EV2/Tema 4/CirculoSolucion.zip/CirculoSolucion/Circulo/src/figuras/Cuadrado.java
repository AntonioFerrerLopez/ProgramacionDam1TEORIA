package figuras;

public class Cuadrado {

    private double lado; // atributo que representa la longitud de un lado del cuadrado

// Método Constructor con un parámetro lad que almacenamos en el atributo lado
    public Cuadrado(double lad) {
        lado = lad;
    }

    public double getLado() {
        return lado;
    }

    public void setLado(double ladoNuevo) {
        lado = ladoNuevo;
    }

    public double area() {
        return lado * lado;
    }

    public double lados() {
        return 4;
    }

    public double perimetro() {
        return 4 * lado;

    }
}
